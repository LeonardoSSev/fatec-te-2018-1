<?php $__env->startSection('title', 'Sobre a empresa'); ?>

<?php $__env->startSection('body'); ?>
    <h1>Sobre a empresa</h1>

    <p>Fundada em 1984, a empresa se consolidou no seguimento de ...</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>