<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(route('concessionaria.store')); ?>">
        <div class="form-group">
            <label for="marca">Marca:</label>
            <input type="text" name="marca" class="form-control">
        </div>
        <div class="form-group">
            <label for="modelo">Modelo:</label>
            <input type="text" name="modelo" class="form-control">
        </div>
        <div class="form-group">
            <label for="ano">Ano:</label>
            <input type="date" name="ano" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-warning">Cadastrar Veículo</button>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('concessionaria.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>