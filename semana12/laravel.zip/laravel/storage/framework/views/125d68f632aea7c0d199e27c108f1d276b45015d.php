<?php $__env->startSection('title', 'Dados para contato'); ?>

<?php $__env->startSection('body'); ?>
    <h1>Dados para contato</h1>

    <p>Entre em contato conosco através dos seguintes e-mails:</p>
    <ul>
        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($email); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <ul>
        <?php foreach($emails as $email): ?>
            <li><?= $email ?></li>
        <?php endforeach; ?>
    </ul>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>