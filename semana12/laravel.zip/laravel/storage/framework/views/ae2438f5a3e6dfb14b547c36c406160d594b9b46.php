<?php $__env->startSection('content'); ?>
<div style="margin-top: 10%;">
    <div>
        <h1>CRUD - Concessionária</h1>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Marca</th>
                <th scope="col">Modelo</th>
                <th scope="col">Ano</th>
                <th scope="col">Editar</th>
                <th scope="col">Excluir</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($veiculo->marca); ?></td>
            <td><?php echo e($veiculo->modelo); ?></td>
            <td><?php echo e($veiculo->ano); ?></td>
            <td><a href="<?php echo e(route('concessionaria.edit', $veiculo->id)); ?>"><i class="fas fa-edit"></i></a></td>
            <td><a href="<?php echo e(route('concessionaria.delete', $veiculo->id)); ?>"><i class="far fa-trash-alt"></i></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('concessionaria.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>