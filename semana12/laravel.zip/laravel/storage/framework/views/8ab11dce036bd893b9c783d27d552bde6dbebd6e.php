<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Minha primeira visão</title>
    </head>
    <body>
        <h1>Minha primeira visão</h1>
        <p>
            <strong>Ola <?php echo e($nome); ?></strong> gerado por meio de uma visão!
        </p>
    </body>
</html>