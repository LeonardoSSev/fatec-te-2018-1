<?php

Route::get('/concessionaria', ['as' => 'concessionaria.home', 'uses' => 'ConcessionariaController@index']);
Route::get('/concessionaria/create', ['as' => 'concessionaria.create', 'uses' => 'ConcessionariaController@create']);
Route::get('/concessionaria/store', ['as' => 'concessionaria.store', 'uses' => 'ConcessionariaController@store']);
Route::get('/concessionaria/edit/{id}', ['as' => 'concessionaria.edit', 'uses' => 'ConcessionariaController@edit']);
Route::get('/concessionaria/update/{id}', ['as' => 'concessionaria.update', 'uses' => 'ConcessionariaController@update']);
Route::get('/concessionaria/delete/{id}', ['as' => 'concessionaria.delete', 'uses' => 'ConcessionariaController@destroy']);
