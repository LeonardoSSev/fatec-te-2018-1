@extends('concessionaria.template')

@section('content')
<div style="margin-top: 10%;">
    <div>
        <h1>CRUD - Concessionária</h1>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Marca</th>
                <th scope="col">Modelo</th>
                <th scope="col">Ano</th>
                <th scope="col">Editar</th>
                <th scope="col">Excluir</th>
            </tr>
        </thead>
        <tbody>
        @foreach($veiculos as $veiculo)
        <tr>
            <td>{{$veiculo->marca}}</td>
            <td>{{$veiculo->modelo}}</td>
            <td>{{$veiculo->ano}}</td>
            <td><a href="{{route('concessionaria.edit', $veiculo->id)}}"><i class="fas fa-edit"></i></a></td>
            <td><a href="{{route('concessionaria.delete', $veiculo->id)}}"><i class="far fa-trash-alt"></i></a></td>
        </tr>
        @endforeach
        </tbody>
    </table>
</div>

@endsection