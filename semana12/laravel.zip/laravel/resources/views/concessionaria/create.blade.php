@extends('concessionaria.template')

@section('content')

    <form action="{{route('concessionaria.store')}}">
        <div class="form-group">
            <label for="marca">Marca:</label>
            <input type="text" name="marca" class="form-control">
        </div>
        <div class="form-group">
            <label for="modelo">Modelo:</label>
            <input type="text" name="modelo" class="form-control">
        </div>
        <div class="form-group">
            <label for="ano">Ano:</label>
            <input type="date" name="ano" class="form-control">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-warning">Cadastrar Veículo</button>
        </div>

    </form>

@endsection