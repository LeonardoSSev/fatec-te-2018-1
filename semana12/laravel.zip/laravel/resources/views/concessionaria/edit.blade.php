@extends('concessionaria.template')

@section('content')
<div style="margin-top: 10%;">
    <div>
        <h1>Editar - {{$veiculo->marca}}</h1>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form action="{{route('concessionaria.update', $veiculo->id)}}">
                <div class="form-group">
                    <label for="marca">Marca:</label>
                    <input type="text" name="marca" class="form-control" value="{{$veiculo->marca}}">
                </div>
                <div class="form-group">
                    <label for="modelo">Modelo:</label>
                    <input type="text" name="modelo" class="form-control" value="{{$veiculo->modelo}}">
                </div>
                <div class="form-group">
                    <label for="ano">Ano:</label>
                    <input type="date" name="ano" class="form-control" value="{{$veiculo->ano}}">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-warning">Editar Veículo</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection